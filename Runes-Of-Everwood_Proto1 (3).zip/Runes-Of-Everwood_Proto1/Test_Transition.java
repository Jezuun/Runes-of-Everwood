import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Test_Transition extends World
{

    /**
     * Constructor for objects of class Test_Transition.
     */
    public Test_Transition()
    {
        super(600, 600, 1);
        

        // Add 4 enemies at random positions
        for (int i = 0; i < 4; i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Enemy(), x, y);
        setPlayer();
    }
}
    /**
     * 
     */
    public void setPlayer()
    {
        Actor player_in_question =  new  player_in_question();
        addObject(player_in_question, 0, 100);
    }
}
