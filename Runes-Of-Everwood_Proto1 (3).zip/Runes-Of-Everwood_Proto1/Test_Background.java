import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import lang.stride.*;
/**
 * Write a description of class Test_Background here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Test_Background extends World
{

    /**
     * Constructor for objects of class Test_Background.
     * 
     */
    public Test_Background()
    {    
         super(800, 600, 1);  // Adjust size as needed

        GreenfootImage title = new GreenfootImage("Runes Of Everwood", 48, Color.WHITE, new Color(0,0,0,0), Color.BLACK); // size 48, bold
        getBackground().drawImage(title, getWidth() / 2 - title.getWidth() / 2, 20); // draw near top center
         GreenfootImage credits = new GreenfootImage("made by: Jesse Oliver Dong-Morin and Gabriel Roberts", 18, Color.WHITE, new Color(0,0,0,0));
        getBackground().drawImage(credits, 10, getHeight() - credits.getHeight() - 10);
        prepare();

    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        
       

        Button1 button1 = new Button1();
        addObject(button1, getWidth() / 2, 400);
    }
}


