import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Test_movement_Input extends World
{

    /**
     * Constructor for objects of class Test_movement_Input.
     */
    public Test_movement_Input()
    {
        super(600, 600, 1);
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        player_in_question player_in_question = new player_in_question();
        addObject(player_in_question,29,223);
    }
}
